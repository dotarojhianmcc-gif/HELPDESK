<?php
// admin.php
include 'db.php';
checkLogin();

if ($_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$statsStmt = $pdo->prepare("
    SELECT 
        (SELECT COUNT(*) FROM users WHERE role IN ('user', 'viewer')) as total_users,
        (SELECT COUNT(*) FROM files) as total_files,
        (SELECT COUNT(*) FROM files WHERE status = 'pending') as pending_files,
    (SELECT COUNT(*) FROM files WHERE status = 'approved' OR (status = 'archived' AND (rejection_reason IS NULL OR rejection_reason = ''))) as approved_files,
    (SELECT COUNT(*) FROM files WHERE status IN ('rejected', 'disapproved') OR (status = 'archived' AND rejection_reason IS NOT NULL AND rejection_reason != '')) as rejected_files,
        (SELECT COUNT(*) FROM files WHERE status = 'archived') as archived_files
");
$statsStmt->execute();
$stats = $statsStmt->fetch();

$pendingStmt = $pdo->prepare("
    SELECT f.*, u.username 
    FROM files f 
    JOIN users u ON f.user_id = u.id 
    WHERE f.status = 'pending' 
    ORDER BY f.uploaded_at DESC
");
$pendingStmt->execute();
$pendingFiles = $pendingStmt->fetchAll();

$allFilesStmt = $pdo->prepare("
    SELECT f.*, u.username, admin_u.username AS approved_by_username 
    FROM files f 
    JOIN users u ON f.user_id = u.id 
    LEFT JOIN users admin_u ON f.approved_by = admin_u.id 
    ORDER BY f.uploaded_at DESC
");
$allFilesStmt->execute();
$allFiles = $allFilesStmt->fetchAll();

$usersStmt = $pdo->prepare("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC");
$usersStmt->execute();
$users = $usersStmt->fetchAll();

$notifStmt = $pdo->prepare("SELECT id, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$notifStmt->execute([$_SESSION['user_id']]);
$adminNotifications = $notifStmt->fetchAll();

$unreadAdminCount = 0;
foreach ($adminNotifications as $notif) {
    if (!$notif['is_read']) {
        $unreadAdminCount++;
    }
}

// Get all upload history with user details for tracking
$trackingStmt = $pdo->prepare("
    SELECT 
        f.id,
        f.file_name,
        f.file_size,
        f.status,
        f.uploaded_at,
        f.approved_at,
        f.rejection_reason,
        u.username,
        u.id as user_id,
        admin_u.username as approved_by_username
    FROM files f 
    JOIN users u ON f.user_id = u.id 
    LEFT JOIN users admin_u ON f.approved_by = admin_u.id 
    ORDER BY f.uploaded_at DESC
");
$trackingStmt->execute();
$trackingHistory = $trackingStmt->fetchAll();

$totalUsersCount = (int) ($stats['total_users'] ?? 0);
$totalFilesCount = (int) ($stats['total_files'] ?? 0);
$pendingFilesCount = (int) ($stats['pending_files'] ?? 0);
$approvedFilesCount = (int) ($stats['approved_files'] ?? 0);
$rejectedFilesCount = (int) ($stats['rejected_files'] ?? 0);
$archivedFilesCount = (int) ($stats['archived_files'] ?? 0);
$archivedFiles = array_values(array_filter($allFiles, fn($row) => normalizeFileStatus($row['status'] ?? '') === 'archived'));
$activeFiles = array_values(array_filter($allFiles, fn($row) => normalizeFileStatus($row['status'] ?? '') !== 'archived'));
$safeTotalFiles = max($totalFilesCount, 1);
$approvedRateAdmin = (int) round(($approvedFilesCount / $safeTotalFiles) * 100);
$pendingRateAdmin = (int) round(($pendingFilesCount / $safeTotalFiles) * 100);
$rejectedRateAdmin = (int) round(($rejectedFilesCount / $safeTotalFiles) * 100);
$archivedRateAdmin = (int) round(($archivedFilesCount / $safeTotalFiles) * 100);

$hasCategory = tableColumnExists($pdo, 'files', 'category');
$topics = loadTopics();
$templateSections = [];
$displayTopics = [];
$mainTopics = [];

foreach ($topics as $topicName) {
    $rawTopic = trim((string) $topicName);
    if ($rawTopic === '') {
        continue;
    }

    if (strpos($rawTopic, ' / ') !== false) {
        [$parentTopic, $subsection] = array_map('trim', explode(' / ', $rawTopic, 2));
        if ($parentTopic === '' || $subsection === '') {
            continue;
        }

        if (!isset($templateSections[$parentTopic])) {
            $templateSections[$parentTopic] = [];
        }

        if (!in_array($subsection, $templateSections[$parentTopic], true)) {
            $templateSections[$parentTopic][] = $subsection;
        }

        if (!in_array($parentTopic, $displayTopics, true)) {
            $displayTopics[] = $parentTopic;
        }
        continue;
    }

    if (!isset($templateSections[$rawTopic])) {
        $templateSections[$rawTopic] = [];
    }

    if (!in_array($rawTopic, $displayTopics, true)) {
        $displayTopics[] = $rawTopic;
    }
}

$mainTopics = $displayTopics;

$topicHierarchy = [];
foreach ($topics as $topicName) {
    $rawTopic = trim((string) $topicName);
    if ($rawTopic === '') {
        continue;
    }

    $parts = array_values(array_filter(array_map('trim', explode(' / ', $rawTopic)), fn($part) => $part !== ''));
    if (empty($parts)) {
        continue;
    }

    $currentBranch =& $topicHierarchy;
    foreach ($parts as $part) {
        if (!isset($currentBranch[$part])) {
            $currentBranch[$part] = [];
        }
        $currentBranch =& $currentBranch[$part];
    }
    unset($currentBranch);
}

function renderNestedTopicButtons(array $nodes, string $prefix, string $leafHandler): void
{
    foreach ($nodes as $label => $children) {
        $path = $prefix !== '' ? $prefix . ' / ' . $label : $label;
        if (!empty($children)) {
            ?>
            <div class="topic-subitem-group">
                <button type="button" class="topic-subitem topic-subitem-parent" aria-expanded="false" onclick="toggleNestedTopicBranch(this)">
                    <span class="topic-subitem-label"><?php echo htmlspecialchars($label); ?></span>
                    <span class="topic-subitem-arrow">▾</span>
                </button>
                <div class="topic-subitem-children">
                    <?php renderNestedTopicButtons($children, $path, $leafHandler); ?>
                </div>
            </div>
            <?php
            continue;
        }
        ?>
        <button type="button" class="topic-subitem topic-subitem-leaf" data-value="<?php echo htmlspecialchars($path); ?>" onclick='<?php echo $leafHandler; ?>(<?php echo json_encode($path); ?>)'>
            <span class="topic-subitem-label"><?php echo htmlspecialchars($label); ?></span>
        </button>
        <?php
    }
}

function renderNestedTopicOptions(array $nodes, string $prefix): void
{
    foreach ($nodes as $label => $children) {
        $path = $prefix !== '' ? $prefix . ' / ' . $label : $label;
        ?>
        <option value="<?php echo htmlspecialchars($path); ?>"><?php echo htmlspecialchars($path); ?></option>
        <?php
        if (!empty($children)) {
            renderNestedTopicOptions($children, $path);
        }
    }
}

function findAdminNotificationDocument(array $notification, array $allFiles): ?array
{
    $message = strtolower((string) ($notification['message'] ?? ''));

    foreach ($allFiles as $document) {
        $name = strtolower((string) ($document['file_name'] ?? ''));
        if ($name !== '' && strpos($message, $name) !== false) {
            return $document;
        }
    }

    return null;
}

function formatAdminNotificationMessage(array $notification, ?array $linkedDocument = null): string
{
    $message = trim((string) ($notification['message'] ?? ''));
    if ($message === '') {
        return 'New notification';
    }

    $lowerMessage = strtolower($message);
    if (strpos($lowerMessage, 'admin ') === 0) {
        return $message;
    }

    $uploaderName = trim((string) ($linkedDocument['username'] ?? ''));
    if ($uploaderName !== '') {
        $isUploadNotice = strpos($lowerMessage, 'uploaded') !== false
            || strpos($lowerMessage, 'resubmitted') !== false
            || strpos($lowerMessage, 'for admin review') !== false;
        if ($isUploadNotice) {
            $namePrefix = strtolower($uploaderName . ' ');
            if (strpos($lowerMessage, $namePrefix) === 0) {
                return $message;
            }

            return $uploaderName . ' ' . $message;
        }
    }

    return $message;
}

$topicRows = [];
if (tableExists($pdo, 'topics')) {
    $topicStmt = $pdo->query("SELECT id, name, created_at FROM topics ORDER BY created_at DESC");
    $topicRows = $topicStmt->fetchAll(PDO::FETCH_ASSOC);
}

$flashMessage = '';
if (!empty($_SESSION['flash_message'])) {
    $flashMessage = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Support HelpDesk</title>
    <link rel="icon" type="image/svg+xml" href="logo.svg?v=20260408e">
    <link rel="shortcut icon" href="logo.svg?v=20260408e">
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__.'/style.css'); ?>">
    <style>
        .tracking-table {
            font-size: 0.9em;
        }
        .tracking-row-pending {
            background-color: rgba(255, 193, 7, 0.05);
        }
        .tracking-row-approved {
            background-color: rgba(40, 167, 69, 0.05);
        }
        .tracking-row-rejected,
        .tracking-row-disapproved {
            background-color: rgba(220, 53, 69, 0.05);
        }
        .tracking-row-archived {
            background-color: rgba(108, 122, 141, 0.08);
        }
        .rejection-note {
            color: #dc3545;
            font-weight: 500;
            padding: 4px 8px;
            background-color: #f8d7da;
            border-radius: 4px;
            display: inline-block;
        }
        .btn-small {
            padding: 4px 8px;
            font-size: 0.85em;
            text-decoration: none;
            display: inline-block;
        }
        .table-action-group {
            display: flex;
            flex-wrap: nowrap;
            gap: 6px;
            justify-content: center;
            align-items: center;
        }
        .all-documents-table {
            width: 100%;
        }
        .all-documents-table td {
            vertical-align: middle;
        }
        .all-documents-table th:nth-child(1) {
            min-width: 160px;
        }
        .all-documents-table th:nth-child(8) {
            min-width: 180px;
        }
        .all-documents-table th:last-child,
        .all-documents-table td:last-child {
            text-align: center;
        }
        .all-documents-table td:nth-child(2),
        .all-documents-table td:nth-child(3),
        .all-documents-table td:nth-child(4),
        .all-documents-table td:nth-child(5),
        .all-documents-table td:nth-child(6),
        .all-documents-table td:nth-child(7) {
            white-space: nowrap;
        }
        .all-documents-table td:first-child {
            line-height: 1.45;
        }
        .all-documents-table .table-action-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4px;
            width: 100%;
        }
        .all-documents-table .table-action-group .btn-small,
        .all-documents-table .table-action-group .btn-primary,
        .all-documents-table .table-action-group .btn-edit,
        .all-documents-table .table-action-group .btn-archive,
        .all-documents-table .table-action-group .btn-unarchive,
        .all-documents-table .table-action-group .btn-delete {
            min-width: unset;
            width: 100%;
            padding: 7px 4px;
            font-size: 11px;
            text-align: center;
        }
        .table-action-group .btn-small,
        .table-action-group .btn-primary,
        .table-action-group .btn-edit,
        .table-action-group .btn-archive,
        .table-action-group .btn-unarchive,
        .table-action-group .btn-delete,
        .table-action-group .btn-approve,
        .table-action-group .btn-reject,
        .table-action-group .action-icon,
        .va-actions .va-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: unset;
            padding: 7px 10px;
            border: none;
            border-radius: 10px;
            background: #eef4ff;
            color: #1c4ea1;
            font-size: 11px;
            font-weight: 700;
            line-height: 1;
            text-decoration: none;
            box-shadow: none;
            cursor: pointer;
            transition: transform 0.18s ease, background-color 0.18s ease, color 0.18s ease, box-shadow 0.18s ease;
            transform-origin: center;
            will-change: transform;
        }
        .table-action-group .btn-small:hover,
        .table-action-group .btn-primary:hover,
        .table-action-group .btn-edit:hover,
        .table-action-group .btn-archive:hover,
        .table-action-group .btn-unarchive:hover,
        .table-action-group .btn-delete:hover,
        .table-action-group .btn-approve:hover,
        .table-action-group .btn-reject:hover,
        .table-action-group .action-icon:hover,
        .va-actions .va-btn:hover {
            background: #dfe9ff;
            color: #163d82;
            box-shadow: 0 10px 22px rgba(28, 78, 161, 0.18);
        }
        .table-action-group .btn-small:active,
        .table-action-group .btn-primary:active,
        .table-action-group .btn-edit:active,
        .table-action-group .btn-archive:active,
        .table-action-group .btn-unarchive:active,
        .table-action-group .btn-delete:active,
        .table-action-group .btn-approve:active,
        .table-action-group .btn-reject:active,
        .table-action-group .action-icon:active,
        .va-actions .va-btn:active {
            transform: scale(0.86);
        }
        .table-action-group .btn-small.is-pressing,
        .table-action-group .btn-primary.is-pressing,
        .table-action-group .btn-edit.is-pressing,
        .table-action-group .btn-archive.is-pressing,
        .table-action-group .btn-unarchive.is-pressing,
        .table-action-group .btn-delete.is-pressing,
        .table-action-group .btn-approve.is-pressing,
        .table-action-group .btn-reject.is-pressing,
        .table-action-group .action-icon.is-pressing,
        .va-actions .va-btn.is-pressing {
            animation: actionButtonZoom 0.34s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .va-actions {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: nowrap;
        }
        .btn-small,
        .btn-primary,
        .btn-edit,
        .btn-delete,
        .btn-archive,
        .btn-unarchive,
        .btn-approve,
        .btn-reject,
        .action-icon,
        .va-btn,
        .btn-logout,
        .dashboard-side-btn {
            transform-origin: center;
            will-change: transform;
        }
        .btn-small:active,
        .btn-primary:active,
        .btn-edit:active,
        .btn-delete:active,
        .btn-archive:active,
        .btn-unarchive:active,
        .btn-approve:active,
        .btn-reject:active,
        .action-icon:active,
        .va-btn:active,
        .btn-logout:active,
        .dashboard-side-btn:active {
            transform: scale(0.86);
        }
        .btn-small.is-pressing,
        .btn-primary.is-pressing,
        .btn-edit.is-pressing,
        .btn-delete.is-pressing,
        .btn-archive.is-pressing,
        .btn-approve.is-pressing,
        .btn-reject.is-pressing,
        .action-icon.is-pressing,
        .va-btn.is-pressing,
        .btn-logout.is-pressing,
        .dashboard-side-btn.is-pressing {
            animation: actionButtonZoom 0.34s cubic-bezier(0.22, 1, 0.36, 1);
        }
        @keyframes actionButtonZoom {
            0% {
                transform: scale(1);
                box-shadow: 0 0 0 rgba(28, 78, 161, 0);
            }
            35% {
                transform: scale(0.82);
                box-shadow: 0 4px 10px rgba(28, 78, 161, 0.1);
            }
            72% {
                transform: scale(1.08);
                box-shadow: 0 14px 28px rgba(28, 78, 161, 0.2);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 0 0 rgba(28, 78, 161, 0);
            }
        }
        .btn-edit {
            border: none;
            border-radius: 8px;
            padding: 8px 12px;
            background: #eef4ff;
            color: #1c4ea1;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }
        .btn-edit:hover {
            background: #dfe9ff;
        }
        .edit-banner {
            display: none;
            margin: 0 0 16px;
            padding: 12px 14px;
            border-radius: 12px;
            border: 1px solid #c8daf7;
            background: #eef5ff;
            color: #17438a;
        }
        .edit-banner.active {
            display: block;
        }
        .edit-banner strong {
            display: block;
            margin-bottom: 4px;
        }
        .topic-template-card {
            width: 100%;
            border-radius: 18px;
            transition: none;
            -webkit-tap-highlight-color: transparent;
            overscroll-behavior: contain;
        }
        .topic-template-card:hover {
            transform: none;
            box-shadow: 0 10px 24px rgba(15, 43, 76, 0.05);
        }
        .topic-template-header,
        .topic-template-body,
        .topic-template-body > div,
        .topic-template-arrow {
            transition: none;
        }
        .topic-template-header {
            outline: none;
            box-shadow: none;
            -webkit-tap-highlight-color: transparent;
        }
        .topic-template-header:focus,
        .topic-template-header:active,
        .topic-template-header:focus-visible {
            outline: none;
            box-shadow: none;
        }
        .edit-banner p {
            margin: 0;
            font-size: 13px;
            line-height: 1.45;
        }
        .edit-banner button {
            margin-top: 10px;
        }
        .admin-notification-banner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid;
            animation: slideDown 0.3s ease-out;
        }
        .admin-notification-banner.success {
            background-color: #d4edda;
            color: #155724;
            border-bottom-color: #28a745;
        }
        .admin-notification-banner.info {
            background-color: #d1ecf1;
            color: #0c5460;
            border-bottom-color: #17a2b8;
        }
        .admin-notification-banner-close {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        .admin-notification-banner-close:hover {
            opacity: 1;
        }
        @keyframes slideDown {
            from {
                transform: translateY(-100%);
            }
            to {
                transform: translateY(0);
            }
        }
        .container {
            margin-top: 0;
        }
        .notice-open-link {
            display: block;
            width: 100%;
            padding: 0;
            border: 0;
            background: transparent;
            color: inherit;
            text-align: left;
            text-decoration: none;
            cursor: pointer;
            font: inherit;
        }
        .notice-open-link:hover .notice-message {
            text-decoration: underline;
        }
        .notice-item-actions {
            margin-top: 8px;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
    </style>
</head>
<body data-persist-page-state="1">
    <div class="container">
        <!-- SIDEBAR -->
        <aside class="sidebar admin-sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <img src="logo.svg?v=20260408e" alt="HelpDesk logo">
                </div>
                <div class="sidebar-profile">
                    <h2><?php echo htmlspecialchars(strtoupper($_SESSION['username'])); ?></h2>
                    <p>Support Administrator</p>
                </div>
            </div>

            <nav class="sidebar-nav">
                <a href="#" class="nav-item active" data-page="dashboard">
                    📊 Dashboard
                </a>
                <a href="#" class="nav-item" data-page="upload">
                    📤 Upload Documents
                </a>
                <a href="#" class="nav-item" data-page="pending">
                    ⏳ New Documents
                </a>
                <a href="#" class="nav-item" data-page="allfiles">
                    🎫 All Documents
                </a>
                <a href="#" class="nav-item" data-page="archive">
                    🗄️ Archive List
                </a>
                <a href="#" class="nav-item" data-page="topics">
                    🗂️ Topics
                </a>
                <a href="#" class="nav-item" data-page="users">
                    👥 Manage Users
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="user-info">
                    <p>Agent:</p>
                    <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                </div>
                <a href="logout.php" class="btn-logout">🚪 Logout</a>
            </div>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">
            <header class="top-header">
                <div class="header-left">
                    <h1>Admin Dashboard</h1>
                </div>
                <div class="header-right">
                    <div class="topbar-search-shell" role="search">
                        <input type="text" id="adminGlobalSearch" class="topbar-search-input" placeholder="Search...">
                        <button type="button" class="search-trigger search-trigger-icon" onclick="triggerAdminSearch()" aria-label="Search admin area">
                            <svg class="search-svg" viewBox="0 0 24 24" aria-hidden="true">
                                <circle cx="11" cy="11" r="6.5"></circle>
                                <path d="M16 16L21 21"></path>
                            </svg>
                        </button>
                    </div>
                    <div class="notification-center">
                        <button type="button" class="notification-bell" data-notice-target="adminNoticeMenu" aria-expanded="false" aria-label="Admin notifications">
                            <span class="bell-icon" aria-hidden="true">
                                <svg class="bell-svg" viewBox="0 0 24 24">
                                    <path d="M12 3a4 4 0 0 0-4 4v1.1c0 .7-.24 1.38-.68 1.92L5.6 12.2A2 2 0 0 0 7.16 15h9.68a2 2 0 0 0 1.56-2.8l-1.72-2.18A3.02 3.02 0 0 1 16 8.1V7a4 4 0 0 0-4-4Z"></path>
                                    <path d="M9.5 17a2.5 2.5 0 0 0 5 0"></path>
                                </svg>
                            </span>
                            <span class="badge" id="notif-count"><?php echo $unreadAdminCount; ?></span>
                        </button>
                        <div class="notification-menu" id="adminNoticeMenu">
                            <div class="notification-menu-header">
                                <strong>Recent Notifications</strong>
                                <button type="button" class="notice-read-btn" onclick="markNotificationsRead()">Mark all read</button>
                            </div>
                            <div class="notification-menu-list">
                                <?php if (empty($adminNotifications)): ?>
                                    <p class="notification-empty">No notices yet.</p>
                                <?php else: ?>
                                    <?php foreach ($adminNotifications as $notif): ?>
                                        <?php $linkedDocument = findAdminNotificationDocument($notif, $allFiles); ?>
                                        <?php $displayMessage = formatAdminNotificationMessage($notif, $linkedDocument); ?>
                                        <div class="notice-item <?php echo !$notif['is_read'] ? 'unread' : ''; ?>" data-notification-id="<?php echo $notif['id']; ?>">
                                            <?php if ($linkedDocument): ?>
                                                <a class="notice-open-link" href="view_file.php?file_id=<?php echo (int) $linkedDocument['id']; ?>" target="_blank">
                                                    <span class="notice-message"><?php echo htmlspecialchars($displayMessage); ?></span>
                                                </a>
                                            <?php else: ?>
                                                <button type="button" class="notice-open-link" onclick="openNotificationsPanel('admin-notices')">
                                                    <span class="notice-message"><?php echo htmlspecialchars($displayMessage); ?></span>
                                                </button>
                                            <?php endif; ?>
                                            <small><?php echo date('M d, Y H:i', strtotime($notif['created_at'])); ?></small>

                                            <?php if ($linkedDocument): ?>
                                                <div class="notice-item-actions">
                                                    <a class="btn-small" href="view_file.php?file_id=<?php echo (int) $linkedDocument['id']; ?>" target="_blank">View</a>
                                                    <a class="btn-primary btn-small" href="download.php?file_id=<?php echo (int) $linkedDocument['id']; ?>" target="_blank">Download</a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <span class="time-display" id="timeDisplay"></span>
                </div>
            </header>

            <div class="content-area">
                <!-- DASHBOARD PAGE -->
                <section id="dashboard" class="page-section active">
                    <div class="dashboard-header-section">
                        <div class="dashboard-top">
                            <h1>Dashboard</h1>
                        </div>
                    </div>

                    <div class="stats-grid admin-stats">
                        <div class="stat-card">
                            <div class="stat-icon">👥</div>
                            <div class="stat-number"><?php echo $totalUsersCount; ?></div>
                            <div class="stat-label">Total Login Users</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">🎫</div>
                            <div class="stat-number"><?php echo $stats['total_files']; ?></div>
                            <div class="stat-label">Total Documents</div>
                        </div>
                        <div class="stat-card warning">
                            <div class="stat-icon">⏳</div>
                            <div class="stat-number"><?php echo $pendingFilesCount; ?></div>
                            <div class="stat-label">Pending Documents</div>
                        </div>
                        <div class="stat-card success">
                            <div class="stat-icon">✅</div>
                            <div class="stat-number"><?php echo $approvedFilesCount; ?></div>
                            <div class="stat-label">Approved Documents</div>
                        </div>
                        <div class="stat-card danger">
                            <div class="stat-icon">❌</div>
                            <div class="stat-number"><?php echo $rejectedFilesCount; ?></div>
                            <div class="stat-label">Rejected Documents</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">🗄️</div>
                            <div class="stat-number"><?php echo $archivedFilesCount; ?></div>
                            <div class="stat-label">Archived Documents</div>
                        </div>
                    </div>

                    <div class="dashboard-visual-grid">
                        <div class="dashboard-visual-card dashboard-visual-main">
                            <div class="dashboard-panel-head">
                                <div>
                                    <span class="panel-eyebrow">Result</span>
                                    <h3>Support Queue</h3>
                                </div>
                                <span class="panel-badge">Admin View</span>
                            </div>
                            <div class="dashboard-bars">
                                <div class="dashboard-bar">
                                    <span class="bar-label">Users</span>
                                    <div class="bar-track"><span class="bar-fill" style="height: <?php echo max(18, min(100, $totalUsersCount * 10)); ?>%;"></span></div>
                                    <span class="bar-value"><?php echo $totalUsersCount; ?></span>
                                </div>
                                <div class="dashboard-bar">
                                    <span class="bar-label">Pending</span>
                                    <div class="bar-track"><span class="bar-fill warning" style="height: <?php echo max(18, $pendingRateAdmin); ?>%;"></span></div>
                                    <span class="bar-value"><?php echo $pendingFilesCount; ?></span>
                                </div>
                                <div class="dashboard-bar">
                                    <span class="bar-label">Approved</span>
                                    <div class="bar-track"><span class="bar-fill success" style="height: <?php echo max(18, $approvedRateAdmin); ?>%;"></span></div>
                                    <span class="bar-value"><?php echo $approvedFilesCount; ?></span>
                                </div>
                                <div class="dashboard-bar">
                                    <span class="bar-label">Rejected</span>
                                    <div class="bar-track"><span class="bar-fill danger" style="height: <?php echo max(18, $rejectedRateAdmin); ?>%;"></span></div>
                                    <span class="bar-value"><?php echo $rejectedFilesCount; ?></span>
                                </div>
                                <div class="dashboard-bar">
                                    <span class="bar-label">Archive</span>
                                    <div class="bar-track"><span class="bar-fill" style="height: <?php echo max(18, $archivedRateAdmin); ?>%; background: linear-gradient(180deg, #9aa9ba 0%, #6c7a8d 100%);"></span></div>
                                    <span class="bar-value"><?php echo $archivedFilesCount; ?></span>
                                </div>
                            </div>
                            <div class="dashboard-summary-strip">
                                <div><strong><?php echo count($allFiles); ?></strong><span>documents</span></div>
                                <div><strong><?php echo count($trackingHistory); ?></strong><span>history</span></div>
                                <div><strong><?php echo count($users); ?></strong><span>users</span></div>
                            </div>
                        </div>

                        <div class="dashboard-visual-card dashboard-visual-side">
                            <div class="progress-ring" style="--progress: <?php echo $approvedRateAdmin; ?>%;">
                                <span><?php echo $approvedRateAdmin; ?>%</span>
                            </div>
                            <h4>Approved Rate</h4>
                            <p class="dashboard-side-note">Track pending, approved, rejected, and archived files from one admin screen.</p>
                            <ul class="insight-list">
                                <li><span>Total Files</span><strong><?php echo $totalFilesCount; ?></strong></li>
                                <li><span>Pending Queue</span><strong><?php echo $pendingFilesCount; ?></strong></li>
                                <li><span>Rejected Items</span><strong><?php echo $rejectedFilesCount; ?></strong></li>
                                <li><span>Archived Items</span><strong><?php echo $archivedFilesCount; ?></strong></li>
                            </ul>
                            <button type="button" class="dashboard-side-btn" onclick="openViewAllModal()">View All</button>
                        </div>

                        <div class="dashboard-visual-card dashboard-visual-trend">
                            <div class="dashboard-panel-head">
                                <div>
                                    <span class="panel-eyebrow">Analysis</span>
                                    <h3>Operations Trend</h3>
                                </div>
                                <span class="panel-badge">Live Flow</span>
                            </div>
                            <div class="trend-graph">
                                <span class="trend-wave wave-one"></span>
                                <span class="trend-wave wave-two"></span>
                                <span class="trend-wave wave-three"></span>
                                <div class="trend-mini-card">
                                    <strong><?php echo $totalUsersCount; ?></strong>
                                    <span>users active</span>
                                </div>
                            </div>
                            <div class="trend-legend">
                                <span><i class="legend-dot primary"></i> Queue flow</span>
                                <span><i class="legend-dot accent"></i> Support actions</span>
                            </div>
                        </div>
                    </div>

                    <div class="card notice-card" id="admin-notices">
                        <h3>🔔 Notice Center</h3>
                        <div class="notifications-list">
                            <?php if (empty($adminNotifications)): ?>
                                <p class="text-center">No notices yet</p>
                            <?php else: ?>
                                <div class="notification-actions">
                                    <button class="btn-primary" type="button" onclick="markNotificationsRead()">Mark All as Read</button>
                                </div>
                                <?php foreach ($adminNotifications as $notif): ?>
                                    <?php $linkedDocument = findAdminNotificationDocument($notif, $allFiles); ?>
                                    <?php $displayMessage = formatAdminNotificationMessage($notif, $linkedDocument); ?>
                                    <div class="notification-item <?php echo !$notif['is_read'] ? 'unread' : ''; ?>" data-notification-id="<?php echo $notif['id']; ?>">
                                        <p><?php echo htmlspecialchars($displayMessage); ?></p>
                                        <small><?php echo date('M d, Y H:i', strtotime($notif['created_at'])); ?></small>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card">
                        <h3>📊 Documents Overview</h3>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Document Name</th>
                                        <th>Topic</th>
                                        <th>Type</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($activeFiles)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">No documents available</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach (array_slice($activeFiles, 0, 10) as $file): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($file['username']); ?></td>
                                                <td><?php echo htmlspecialchars($file['file_name']); ?></td>
                                                <td><?php echo htmlspecialchars($file['category'] ?? '—'); ?></td>
                                                <td>File</td>
                                                <td><?php echo date('M d, Y', strtotime($file['uploaded_at'])); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo formatFileStatusClass($file['status']); ?>">
                                                        <?php echo formatFileStatusLabel($file['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="table-action-group">
                                                        <a class="btn-small" href="view_file.php?file_id=<?php echo $file['id']; ?>" target="_blank">View</a>
                                                        <a class="btn-primary" href="download.php?file_id=<?php echo $file['id']; ?>" target="_blank">Download</a>
                                                        <?php if ((int) $file['user_id'] === (int) $_SESSION['user_id'] && normalizeFileStatus($file['status']) !== 'archived'): ?>
                                                            <button type="button" class="btn-edit" onclick='openEditUpload(<?php echo (int) $file["id"]; ?>, <?php echo json_encode($file["category"] ?? ""); ?>, <?php echo json_encode($file["file_name"]); ?>)'>Edit</button>
                                                        <?php endif; ?>
                                                        <?php if (in_array(normalizeFileStatus($file['status']), ['approved', 'rejected'])): ?>
                                                            <button type="button" class="btn-small btn-archive" onclick="archiveFile(<?php echo $file['id']; ?>)">Archive</button>
                                                        <?php endif; ?>
                                                        <?php if (normalizeFileStatus($file['status']) === 'approved'): ?>
                                                            <button type="button" class="btn-small btn-delete" onclick="deleteFile(<?php echo $file['id']; ?>)">Delete</button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- PENDING DOCUMENTS PAGE -->
                <section id="pending" class="page-section">
                    <div class="card">
                        <h2>⏳ Pending Documents (<?php echo count($pendingFiles); ?>)</h2>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Document Name</th>
                                        <?php if ($hasCategory): ?>
                                            <th>Topic</th>
                                        <?php endif; ?>
                                        <th>From User</th>
                                        <th>Size</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($pendingFiles)): ?>
                                        <tr>
                                            <td colspan="<?php echo $hasCategory ? 6 : 5; ?>" class="text-center">✅ No pending documents!</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($pendingFiles as $file): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($file['file_name']); ?></td>
                                                <?php if ($hasCategory): ?>
                                                    <td><?php echo htmlspecialchars($file['category'] ?? '—'); ?></td>
                                                <?php endif; ?>
                                                <td><?php echo htmlspecialchars($file['username']); ?></td>
                                                <td><?php echo number_format($file['file_size'] / 1024, 2); ?> KB</td>
                                                <td><?php echo date('M d, Y H:i', strtotime($file['uploaded_at'])); ?></td>
                                                <td>
                                                    <div class="table-action-group">
                                                        <a class="btn-small" href="view_file.php?file_id=<?php echo $file['id']; ?>" target="_blank">
                                                            View
                                                        </a>
                                                        <a class="btn-primary" href="download.php?file_id=<?php echo $file['id']; ?>" target="_blank">
                                                            Download
                                                        </a>
                                                        <?php if ((int) $file['user_id'] === (int) $_SESSION['user_id']): ?>
                                                        <button class="btn-edit" type="button" onclick='openEditUpload(<?php echo (int) $file["id"]; ?>, <?php echo json_encode($file["category"] ?? ""); ?>, <?php echo json_encode($file["file_name"]); ?>)'>Edit</button>
                                                        <?php endif; ?>
                                                        <button class="btn-approve" onclick="approveFile(<?php echo $file['id']; ?>)">
                                                            ✅ Approve
                                                        </button>
                                                        <button class="btn-reject" onclick="rejectFile(<?php echo $file['id']; ?>)">
                                                            ❌ Reject
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- ALL DOCUMENTS PAGE -->
                <section id="allfiles" class="page-section">
                    <div class="card">
                        <h2>🎫 All Documents (<?php echo count($activeFiles); ?>)</h2>
                        <div class="table-container">
                            <table class="data-table all-documents-table" id="filesTable">
                                <thead>
                                    <tr>
                                        <th>Document Name</th>
                                        <th>User</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th>Processed</th>
                                        <th>Processed By</th>
                                        <th>Remarks</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($activeFiles as $file): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($file['file_name']); ?></td>
                                            <td><?php echo htmlspecialchars($file['username']); ?></td>
                                            <td>
                                                <span class="status-badge status-<?php echo formatFileStatusClass($file['status']); ?>">
                                                    <?php echo formatFileStatusLabel($file['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y H:i', strtotime($file['uploaded_at'])); ?></td>
                                            <td><?php echo $file['approved_at'] ? date('M d, Y H:i', strtotime($file['approved_at'])) : '—'; ?></td>
                                            <td><?php echo htmlspecialchars($file['approved_by_username'] ?? '—'); ?></td>
                                            <td><?php echo !empty($file['rejection_reason']) ? htmlspecialchars($file['rejection_reason']) : '—'; ?></td>
                                            <td>
                                                <div class="table-action-group">
                                                    <a class="btn-small" href="view_file.php?file_id=<?php echo $file['id']; ?>" target="_blank">
                                                        View
                                                    </a>
                                                    <a class="btn-primary" href="download.php?file_id=<?php echo $file['id']; ?>" target="_blank">
                                                        Download
                                                    </a>
                                                    <?php if ((int) $file['user_id'] === (int) $_SESSION['user_id'] && normalizeFileStatus($file['status']) !== 'archived'): ?>
                                                    <button class="btn-edit" type="button" onclick='openEditUpload(<?php echo (int) $file["id"]; ?>, <?php echo json_encode($file["category"] ?? ""); ?>, <?php echo json_encode($file["file_name"]); ?>)'>Edit</button>
                                                    <?php endif; ?>
                                                    <?php if (normalizeFileStatus($file['status']) === 'approved'): ?>
                                                        <button class="btn-archive" type="button" onclick="archiveFile(<?php echo $file['id']; ?>)">
                                                            Archive
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if (normalizeFileStatus($file['status']) === 'approved'): ?>
                                                    <button class="btn-delete" onclick="deleteFile(<?php echo $file['id']; ?>)">
                                                        Delete
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- TRACKING & HISTORY PAGE -->
                <section id="tracking" class="page-section">
                    <div class="card">
                        <h2>📊 Document Tracking & History (<?php echo count($trackingHistory); ?>)</h2>
                        <div class="filter-bar">
                            <input type="text" id="searchTracking" placeholder="🔍 Search by document name or user...">
                            <select id="filterTrackingStatus">
                                <option value="">All Status</option>
                                <option value="pending">⏳ Pending</option>
                                <option value="approved">✅ Approved</option>
                                <option value="rejected">❌ Rejected</option>
                                <option value="archived">🗄️ Archived</option>
                            </select>
                        </div>
                        <div class="table-container">
                            <table class="data-table tracking-table" id="trackingTable">
                                <thead>
                                    <tr>
                                        <th>Document Name</th>
                                        <th>User</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th>Processed</th>
                                        <th>Processed By</th>
                                        <th>Remarks</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($trackingHistory)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No upload history yet</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($trackingHistory as $track): ?>
                                            <tr class="tracking-row-<?php echo formatFileStatusClass($track['status']); ?>">
                                                <td><?php echo htmlspecialchars($track['file_name']); ?></td>
                                                <td><?php echo htmlspecialchars($track['username']); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo formatFileStatusClass($track['status']); ?>">
                                                        <?php echo formatFileStatusLabel($track['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y H:i', strtotime($track['uploaded_at'])); ?></td>
                                                <td><?php echo $track['approved_at'] ? date('M d, Y H:i', strtotime($track['approved_at'])) : '—'; ?></td>
                                                <td><?php echo htmlspecialchars($track['approved_by_username'] ?? '—'); ?></td>
                                                <td>
                                                    <?php 
                                                    if ($track['rejection_reason']) {
                                                        echo '<span class="rejection-note">' . htmlspecialchars($track['rejection_reason']) . '</span>';
                                                    } else {
                                                        echo '—';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <div class="table-action-group">
                                                        <a class="btn-small" href="view_file.php?file_id=<?php echo $track['id']; ?>" target="_blank">
                                                            View
                                                        </a>
                                                        <a class="btn-small" href="download.php?file_id=<?php echo $track['id']; ?>" target="_blank">
                                                            Download
                                                        </a>
                                                        <?php if ((int) $track['user_id'] === (int) $_SESSION['user_id'] && normalizeFileStatus($track['status']) !== 'archived'): ?>
                                                            <button type="button" class="btn-edit" onclick='openEditUpload(<?php echo (int) $track["id"]; ?>, <?php echo json_encode($track["category"] ?? ""); ?>, <?php echo json_encode($track["file_name"]); ?>)'>Edit</button>
                                                        <?php endif; ?>
                                                        <?php if (in_array(normalizeFileStatus($track['status']), ['approved', 'rejected'])): ?>
                                                            <button type="button" class="btn-small btn-archive" onclick="archiveFile(<?php echo $track['id']; ?>)">Archive</button>
                                                        <?php endif; ?>
                                                        <?php if (normalizeFileStatus($track['status']) === 'approved'): ?>
                                                            <button type="button" class="btn-small btn-delete" onclick="deleteFile(<?php echo $track['id']; ?>)">Delete</button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- ARCHIVE LIST PAGE -->
                <section id="archive" class="page-section">
                    <div class="card">
                        <h2>🗄️ Archive List (<?php echo $archivedFilesCount; ?>)</h2>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Document Name</th>
                                        <th>Topic</th>
                                        <th>User</th>
                                        <th>Archived On</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($archivedFiles)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center">No archived documents yet.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($archivedFiles as $file): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($file['file_name']); ?></td>
                                                <td><?php echo htmlspecialchars($file['category'] ?? '—'); ?></td>
                                                <td><?php echo htmlspecialchars($file['username']); ?></td>
                                                <td><?php echo date('M d, Y H:i', strtotime($file['approved_at'] ?: $file['uploaded_at'])); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo formatFileStatusClass($file['status']); ?>">
                                                        <?php echo formatFileStatusLabel($file['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="table-action-group">
                                                        <a class="btn-small" href="view_file.php?file_id=<?php echo $file['id']; ?>" target="_blank">View</a>
                                                        <a class="btn-small" href="download.php?file_id=<?php echo $file['id']; ?>" target="_blank">Download</a>
                                                        <button type="button" class="btn-small btn-unarchive" onclick="unarchiveFile(<?php echo $file['id']; ?>)">Unarchive</button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <!-- ADMIN UPLOAD PAGE -->
                <section id="upload" class="page-section">
                    <div class="card" style="padding: 20px 24px;">
                        <h2 style="margin-bottom: 20px;">📤 Upload Document</h2>
                        <form id="uploadForm" class="upload-form" enctype="multipart/form-data" style="display: block; width: 100%;">
                            <div id="resubmitBanner" class="edit-banner" aria-live="polite" style="display: none;">
                                <strong id="resubmitBannerTitle">Editing file</strong>
                                <p id="resubmitBannerText">Upload the updated version of this file.</p>
                                <button type="button" class="btn-edit" onclick="clearResubmitState()">Cancel edit</button>
                            </div>

                            <input type="hidden" id="resubmitFileId" name="resubmit_file_id" value="">
                            <input type="hidden" id="editFileId" name="edit_file_id" value="">

                            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; margin-bottom: 20px;">
                                <div>
                                    <label style="display:block; font-size:0.82rem; font-weight:600; color:#6b7280; margin-bottom:5px; text-transform:uppercase; letter-spacing:.04em;">Main Topic</label>
                                    <select id="mainTopicSelect" style="width:100%; height: 42px; border:1px solid #d1d5db; border-radius:6px; padding:0 10px;">
                                        <option value="">— Select main topic —</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display:block; font-size:0.82rem; font-weight:600; color:#6b7280; margin-bottom:5px; text-transform:uppercase; letter-spacing:.04em;">Section</label>
                                    <select id="sectionSelect" style="width:100%; height: 42px; border:1px solid #d1d5db; border-radius:6px; padding:0 10px;" disabled>
                                        <option value="">— Select section —</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display:block; font-size:0.82rem; font-weight:600; color:#6b7280; margin-bottom:5px; text-transform:uppercase; letter-spacing:.04em;">Under Section</label>
                                    <select id="underSectionSelect" style="width:100%; height: 42px; border:1px solid #d1d5db; border-radius:6px; padding:0 10px;" disabled>
                                        <option value="">— Select under section —</option>
                                    </select>
                                </div>
                            </div>

                            <select id="topicSelect" name="topic" required class="topic-hidden-select" style="display: none;">
                                <option value="">Choose a section or subsection</option>
                                <?php foreach ($displayTopics as $topic): ?>
                                    <option value="<?php echo htmlspecialchars($topic); ?>"><?php echo htmlspecialchars($topic); ?></option>
                                    <?php renderNestedTopicOptions($topicHierarchy[$topic] ?? [], $topic); ?>
                                <?php endforeach; ?>
                            </select>

                            <span id="selectedTopicLabel" style="display: none;">None</span>

                            <div class="upload-area" id="uploadArea">
                                <div id="uploadPreview">
                                    <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                        <polyline points="17 8 12 3 7 8"></polyline>
                                        <line x1="12" y1="3" x2="12" y2="15"></line>
                                    </svg>
                                    <h3>Drag &amp; Drop Files Here</h3>
                                    <p>or click to browse</p>
                                </div>
                            </div>

                            <input type="file" id="fileInput" name="files[]" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.txt,.zip" hidden>

                            <div class="upload-action-row">
                                <button type="submit" class="btn-primary">📤 Upload File</button>
                                <button type="button" id="cancelUploadButton" class="upload-cancel-btn" hidden>Cancel Upload</button>
                            </div>
                        </form>

                        <script>
                            (function () {
                                const form = document.getElementById('uploadForm');
                                if (!form || form.dataset.topicUiBound === '1') return;
                                form.dataset.topicUiBound = '1';

                                const topicSelect = document.getElementById('topicSelect');
                                const mainSelect = document.getElementById('mainTopicSelect');
                                const sectionSelect = document.getElementById('sectionSelect');
                                const underSelect = document.getElementById('underSectionSelect');

                                if (!topicSelect || !mainSelect || !sectionSelect || !underSelect) return;

                                const allPaths = Array.from(topicSelect.options)
                                    .map(option => option.value.trim())
                                    .filter(Boolean);

                                const tree = {};
                                allPaths.forEach(path => {
                                    const parts = path.split(' / ').map(part => part.trim()).filter(Boolean);
                                    if (!parts.length) return;
                                    const main = parts[0];
                                    const section = parts[1] || '';
                                    const under = parts[2] || '';

                                    if (!tree[main]) {
                                        tree[main] = { sections: new Set(), under: {} };
                                    }

                                    if (section) {
                                        tree[main].sections.add(section);
                                        if (!tree[main].under[section]) {
                                            tree[main].under[section] = new Set();
                                        }
                                        if (under) {
                                            tree[main].under[section].add(under);
                                        }
                                    }
                                });

                                const fillMainOptions = () => {
                                    mainSelect.innerHTML = '<option value="">Select Main Topic</option>';
                                    Object.keys(tree).sort().forEach(main => {
                                        const option = document.createElement('option');
                                        option.value = main;
                                        option.textContent = main;
                                        mainSelect.appendChild(option);
                                    });
                                };

                                const fillSectionOptions = (main) => {
                                    sectionSelect.innerHTML = '<option value="">Select Section</option>';
                                    underSelect.innerHTML = '<option value="">Select Under Section</option>';
                                    underSelect.disabled = true;

                                    if (!main || !tree[main]) {
                                        sectionSelect.disabled = true;
                                        return;
                                    }

                                    const sections = Array.from(tree[main].sections).sort();
                                    sections.forEach(section => {
                                        const option = document.createElement('option');
                                        option.value = section;
                                        option.textContent = section;
                                        sectionSelect.appendChild(option);
                                    });

                                    sectionSelect.disabled = sections.length === 0;
                                };

                                const fillUnderOptions = (main, section) => {
                                    underSelect.innerHTML = '<option value="">Select Under Section</option>';

                                    if (!main || !section || !tree[main] || !tree[main].under[section]) {
                                        underSelect.disabled = true;
                                        return;
                                    }

                                    const underList = Array.from(tree[main].under[section]).sort();
                                    underList.forEach(under => {
                                        const option = document.createElement('option');
                                        option.value = under;
                                        option.textContent = under;
                                        underSelect.appendChild(option);
                                    });

                                    underSelect.disabled = underList.length === 0;
                                };

                                const syncHiddenTopic = () => {
                                    const main = mainSelect.value.trim();
                                    const section = sectionSelect.value.trim();
                                    const under = underSelect.value.trim();

                                    let value = '';
                                    if (main && section && under) {
                                        value = main + ' / ' + section + ' / ' + under;
                                    } else if (main && section) {
                                        value = main + ' / ' + section;
                                    } else if (main) {
                                        value = main;
                                    }

                                    if (value && !allPaths.includes(value)) {
                                        const sectionPrefix = main && section ? (main + ' / ' + section + ' / ') : '';
                                        const deepMatch = sectionPrefix ? allPaths.find(path => path.startsWith(sectionPrefix)) : '';
                                        value = deepMatch || (allPaths.includes(main + ' / ' + section) ? (main + ' / ' + section) : (main || ''));
                                    }

                                    topicSelect.value = value;
                                    topicSelect.dispatchEvent(new Event('change', { bubbles: true }));
                                };

                                const syncVisibleFromHidden = () => {
                                    const parts = (topicSelect.value || '').split(' / ').map(part => part.trim()).filter(Boolean);
                                    const main = parts[0] || '';
                                    const section = parts[1] || '';
                                    const under = parts[2] || '';

                                    fillMainOptions();
                                    mainSelect.value = main;
                                    fillSectionOptions(main);
                                    sectionSelect.value = section;
                                    fillUnderOptions(main, section);
                                    underSelect.value = under;
                                };

                                fillMainOptions();
                                syncVisibleFromHidden();

                                mainSelect.addEventListener('change', () => {
                                    fillSectionOptions(mainSelect.value.trim());
                                    sectionSelect.value = '';
                                    fillUnderOptions(mainSelect.value.trim(), '');
                                    syncHiddenTopic();
                                });

                                sectionSelect.addEventListener('change', () => {
                                    fillUnderOptions(mainSelect.value.trim(), sectionSelect.value.trim());
                                    underSelect.value = '';
                                    syncHiddenTopic();
                                });

                                underSelect.addEventListener('change', syncHiddenTopic);
                                topicSelect.addEventListener('change', syncVisibleFromHidden);
                            })();
                        </script>
                    </div>
                </section>

                <!-- MANAGE TOPICS PAGE -->
                <section id="topics" class="page-section">
                    <div class="card">
                        <h2>🗂️ Manage Sections</h2>
                        <div class="topic-manager" data-topics="<?php echo htmlspecialchars(json_encode(array_values($topics)), ENT_QUOTES, 'UTF-8'); ?>">
                            <div class="topic-guide-grid">
                                <div class="topic-guide-card">
                                    <h3>Main Topic</h3>
                                    <div class="topic-add topic-add-stack">
                                        <input type="text" id="newTopicInput" placeholder="Main topic name" aria-label="Main topic name" />
                                        <button type="button" class="btn-primary" onclick="addTopic()">Add Main Topic</button>
                                    </div>
                                </div>
                                <div class="topic-guide-card">
                                    <h3>Section</h3>
                                    <div class="topic-add topic-add-stack">
                                        <select id="parentTopicSelect">
                                            <option value="">Choose main topic</option>
                                            <?php foreach ($mainTopics as $mainTopic): ?>
                                                <option value="<?php echo htmlspecialchars($mainTopic); ?>"><?php echo htmlspecialchars($mainTopic); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="text" id="newSectionInput" placeholder="Section name" aria-label="Section name" />
                                        <button type="button" class="btn-primary" onclick="addSection()">Add Section</button>
                                    </div>
                                </div>
                                <div class="topic-guide-card">
                                    <h3>Under Section</h3>
                                    <div class="topic-add topic-add-stack">
                                        <select id="sectionParentSelect">
                                            <option value="">Choose section</option>
                                        </select>
                                        <input type="text" id="underSectionInput" placeholder="Under section name" aria-label="Under section name" />
                                        <button type="button" class="btn-primary" onclick="addUnderSection()">Add Under Section</button>
                                    </div>
                                </div>
                            </div>

                            <div class="topic-guide-preview">
                                <div id="topicList" class="topic-tree-list"></div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- MANAGE USERS PAGE -->
                <section id="users" class="page-section">
                    <div class="card">
                        <h2>👥 Manage Users (<?php echo count($users); ?>)</h2>
                        <div class="filter-bar">
                            <input type="text" id="searchUsers" placeholder="Search by username, email, or role...">
                        </div>
                        <div class="table-container">
                            <table class="data-table" id="usersTable">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Joined</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td>
                                                <span class="role-badge role-<?php echo $user['role']; ?>">
                                                    <?php echo ucfirst($user['role']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                            <td>
                                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                    <button class="btn-delete" onclick="deleteUser(<?php echo $user['id']; ?>)">
                                                        Delete
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-muted">Self</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <!-- VIEW ALL FILES MODAL -->
    <div id="viewAllModal" class="va-modal va-modal-hidden">
        <div class="va-dialog">
            <div class="va-dialog-head">
                <h3>&#128196; All Files</h3>
                <button type="button" class="va-close" onclick="closeViewAllModal()" aria-label="Close">&times;</button>
            </div>
            <div class="va-search-bar">
                <input type="text" id="vaSearchInput" placeholder="Search file name, status, category..." oninput="filterViewAll(this.value)" />
            </div>
            <div class="va-table-wrap">
                <table class="va-table" id="vaTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>File Name</th>
                            <th>Category</th>
                            <th>Uploaded By</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="vaTableBody">
                        <?php foreach ($activeFiles as $i => $vf): ?>
                        <tr class="va-row" data-search="<?php echo htmlspecialchars(strtolower($vf['file_name'] . ' ' . ($vf['category'] ?? '') . ' ' . $vf['status'] . ' ' . $vf['username'])); ?>">
                            <td><?php echo $i + 1; ?></td>
                            <td class="va-fname"><?php echo htmlspecialchars($vf['file_name']); ?></td>
                            <td><?php echo htmlspecialchars($vf['category'] ?? '—'); ?></td>
                            <td><?php echo htmlspecialchars($vf['username']); ?></td>
                            <td><span class="va-status va-status-<?php echo htmlspecialchars(strtolower($vf['status'])); ?>"><?php echo ucfirst(htmlspecialchars($vf['status'])); ?></span></td>
                            <td><?php echo date('M d, Y', strtotime($vf['uploaded_at'])); ?></td>
                            <td class="va-actions">
                                <a href="view_file.php?file_id=<?php echo (int)$vf['id']; ?>" target="_blank" class="va-btn">View</a>
                                <a href="download.php?file_id=<?php echo (int)$vf['id']; ?>" target="_blank" class="va-btn">Download</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($activeFiles)): ?>
                        <tr><td colspan="7" style="text-align:center;padding:24px;color:#888;">No files found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="va-footer">
                <span id="vaCount"><?php echo count($activeFiles); ?> file(s)</span>
            </div>
        </div>
    </div>

    <script src="script.js?v=<?php echo filemtime(__DIR__.'/script.js'); ?>"></script>
    <?php if (!empty($flashMessage)): ?>
        <script>
            alert('<?php echo addslashes($flashMessage); ?>');
        </script>
    <?php endif; ?>
    <script>
        // Update time display
        function updateTime() {
            const now = new Date();
            document.getElementById('timeDisplay').textContent = now.toLocaleTimeString();
        }
        setInterval(updateTime, 1000);
        updateTime();
    </script>
</body>
</html>